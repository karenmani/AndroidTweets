package edu.gwu.androidtweetsfall2019

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseUser

class MainActivity : AppCompatActivity() {

    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var login: Button
    private lateinit var signUp: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createNotificationChannel()
        firebaseAuth = FirebaseAuth.getInstance()
        firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        Log.d("MainActivity", "onCreate called")

        val preferences = getSharedPreferences("android-tweets", Context.MODE_PRIVATE)

        //search radius will be remembered in the project
        username = findViewById(R.id.username)
        password = findViewById(R.id.password)
        login = findViewById(R.id.login)
        signUp = findViewById(R.id.signUp)
        progressBar = findViewById(R.id.progressBar)

        login.isEnabled = false
        username.setText(preferences.getString("Saved_username", ""))

        username.addTextChangedListener(textWatcher)
        password.addTextChangedListener(textWatcher)

        login.setOnClickListener {
            val inputtedUsername: String = username.text.toString().trim()
            val inputtedPassword: String = password.text.toString().trim()

            firebaseAuth
                .signInWithEmailAndPassword(inputtedUsername, inputtedPassword)
                .addOnCompleteListener {
                        task ->


                    if(task.isSuccessful) {
                        val currentUser: FirebaseUser? = firebaseAuth.currentUser
                        val email = currentUser?.email
                        Toast.makeText(this, "Logged in as $email", Toast.LENGTH_SHORT).show()
                        preferences
                            .edit()
                            .putString("Saved_username", username.text.toString())
                            .apply()
                        val intent = Intent(this, MapsActivity::class.java)
                        intent.putExtra("LOCATION", "Washington D.C.")
                        startActivity(intent)
                    } else {
                        val exception = task.exception
                        val reason = if(exception is FirebaseAuthInvalidCredentialsException) "invalid_credentials" else "connection_failure"
                        val bundle = Bundle()
                        bundle.putString("error_type", reason)

                        firebaseAnalytics.logEvent("login_failed", null)
                    }
                }
        }

        signUp.setOnClickListener {
            val inputtedUsername: String = username.text.toString().trim()
            val inputtedPassword: String = password.text.toString().trim()
            firebaseAuth
                .createUserWithEmailAndPassword(inputtedUsername, inputtedPassword)
                .addOnCompleteListener { task ->
                    if(task.isSuccessful) {
                        val currentUser: FirebaseUser? = firebaseAuth.currentUser
                        val email = currentUser?.email
                        Toast.makeText(this, "Registration Successful as $email", Toast.LENGTH_SHORT).show()

                        showNotification()
                    } else {
                        val exception = task.exception
                        Toast.makeText(this, "Registration Failed: $exception", Toast.LENGTH_SHORT).show()
                    }
                }

        }
    }

    private fun showNotification() {
        val tweetsIntent = Intent(this, TweetsActivity::class.java)
        tweetsIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
        tweetsIntent.putExtra("address", "2121 I St NW")
        tweetsIntent.putExtra("state", "Virginia")
        tweetsIntent.putExtra("latitude", 38.8997145)
        tweetsIntent.putExtra("longitude", -77.0485992)

        //val pendingIntent = PendingIntent.getActivity(this, 0, tweetsIntent, 0)
        val pendingIntentBuilder = TaskStackBuilder.create(this)
        pendingIntentBuilder.addNextIntentWithParentStack(tweetsIntent)
        val pendingIntent = pendingIntentBuilder.getPendingIntent(
            0,
            PendingIntent.FLAG_UPDATE_CURRENT)

        val builder = NotificationCompat.Builder(this, "default")
            .setSmallIcon(R.drawable.ic_check_white)
            .setContentTitle("Android Tweets")
            .setContentText("Welcome to Android Tweets!")
            .addAction(0, "Go To Virginia", pendingIntent)
            //.setContentIntent(pendingIntent)
        NotificationManagerCompat.from(this).notify(0, builder.build())
    }

    private fun createNotificationChannel() {
        // Only needed for Android Oreo and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Default Notifications"
            val descriptionText = "The app's default notification set"
            val importance = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel("default", name, importance)
            channel.description = descriptionText

            // Register the channel with the system
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }




    private val textWatcher = object : TextWatcher {
        override fun afterTextChanged(p0: Editable?) {}

        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

        override fun onTextChanged(newString: CharSequence, start: Int, before: Int, count: Int) {
            val inputtedUsername: String = username.text.toString().trim()
            val inputtedPassword: String = password.text.toString().trim()
            val enabled: Boolean = inputtedUsername.isNotEmpty() && inputtedPassword.isNotEmpty()

            login.isEnabled = true

            //sets username and password to a string and then enables Login button when typed in
        }

    }

    override fun onResume() {
        super.onResume()
        Log.d("MainActivity", "onResume called")
    }

    override fun onPause() {
        super.onPause()
        Log.d("MainActivity", "onPause called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MainActivity", "onDestroy called")
    }
}
