package edu.gwu.androidtweetsfall2019

import java.io.Serializable

data class Tweet constructor(
        val name: String,
        val handle: String,
        val content: String,
        val iconUrl: String
    ): Serializable {
        constructor(content: String) : this("", "", "", "")
    }
