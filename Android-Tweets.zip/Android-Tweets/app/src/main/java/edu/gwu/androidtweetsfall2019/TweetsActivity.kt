package edu.gwu.androidtweetsfall2019

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.maps.model.LatLng
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import org.jetbrains.anko.AnkoAsyncContext
import org.jetbrains.anko.doAsync


class TweetsActivity : AppCompatActivity() {
    private val currentTweets: MutableList<Tweet> = mutableListOf()
    private lateinit var recyclerView: RecyclerView
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var addTweet: FloatingActionButton
    private lateinit var tweetContent: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tweets)

        //val location: String = intent.getStringExtra("LOCATION") //intent=getter
        val address: String = intent.getStringExtra("address")
        val state: String = intent.getStringExtra("state")
        val latitude: Double = intent.getDoubleExtra("latitude", 0.0)
        val longitude: Double = intent.getDoubleExtra("longitude", 0.0)

        title = getString(R.string.tweets_title)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        addTweet = findViewById<FloatingActionButton>(R.id.add_tweet)
        tweetContent = findViewById(R.id.tweet_content)

        if(savedInstanceState != null) {
            val savedTweets = savedInstanceState.getSerializable("TWEETS") as ArrayList<Tweet>
            currentTweets.addAll(savedTweets)
            recyclerView.adapter = TweetsAdapter(currentTweets)
        } else {
            getTweetsFromTwitter(latitude, longitude)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putSerializable("TWEETS", ArrayList(currentTweets))
    }

        fun getTweetsFromTwitter(latitude: Double, longitude: Double) {
            addTweet.hide()
            tweetContent.visibility = View.GONE
            doAsync {
                val twitterManager = TwitterManager()
                try {

                    val apiKey = getString(R.string.api_key)
                    val apiSecret = getString(R.string.api_secret)

                    val oAuthToken = twitterManager.retrieveOAuthToken(
                        apiKey = apiKey,
                        apiSecret = apiSecret
                    )


                    val tweets = twitterManager.retrieveTweets(
                        oAuthToken = oAuthToken,
                        latLng = LatLng(latitude, longitude)
                    )
                    currentTweets.clear()
                    currentTweets.addAll(tweets)


                    //set adapter or you wont have a displayed list
                    runOnUiThread {
                        recyclerView.adapter = TweetsAdapter(getFakeTweets())
                    }
                }
                catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@TweetsActivity, "Error retrieving Tweets",
                            Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        fun getTweetsFromFirebase(state: String) {
            val reference = firebaseDatabase.getReference("tweets/$state")
            addTweet.setOnClickListener {
                val content = tweetContent.text.toString()
                if (content.isNotEmpty()) {
                    val email = FirebaseAuth.getInstance().currentUser?.email ?: ""
                    val tweet = Tweet(
                        name = email,
                        handle = email,
                        content = content,
                        iconUrl = "http://i.imgur.com/DvpvklR.png"
                    )

                    reference.push().setValue(tweet)
                }
            }

            reference.addValueEventListener(object : ValueEventListener{
                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@TweetsActivity, "Failed to retrieve tweets: $error!", Toast.LENGTH_LONG)
                        .show()
                }

                override fun onDataChange(data: DataSnapshot) {
                    val tweets = mutableListOf<Tweet>()
                    data.children.forEach{ child ->
                        val tweet = child.getValue(Tweet::class.java)
                        if(tweet != null) {
                            tweets.add(tweet)
                        }
                    }

                    recyclerView.adapter = TweetsAdapter(tweets)
                }

            })
        }

        fun getFakeTweets(): List<Tweet> {
            return listOf(
                Tweet("Karen Mani", "@karenmani99", "Happy Monday!", "https://"),
                Tweet("Cissy Petty", "@cissypetty", "Happy Monday!", "https://"),
                Tweet("Thomas LeBlanc", "@tleb", "Happy Monday!", "https://"),
                Tweet("Simon Cowell", "@simoncowell", "Happy Monday!", "https://"),
                Tweet("Macbook Air", "@apple", "I'm better than Dell", "https://")
            )
        }
}


