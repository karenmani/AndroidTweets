package edu.gwu.androidtweetsfall2019

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.Address
import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.os.Build
import android.widget.Toast
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices

import com.google.android.gms.location.LocationRequest
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import org.jetbrains.anko.doAsync


class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var confirm: Button
    private lateinit var currentLocation: ImageButton
    private lateinit var locationProvider: FusedLocationProviderClient
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        firebaseAuth = FirebaseAuth.getInstance()
        val email = firebaseAuth.currentUser?.email
        title = "Welcome $email"
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        confirm = findViewById(R.id.confirm)
        confirm.isEnabled = false;
        currentLocation = findViewById(R.id.current_location)
        checkPermissions()
        locationProvider = LocationServices.getFusedLocationProviderClient(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    private fun checkPermissions() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            getCurrentLocation()
            //we have the permission already
        } else {
            //prompt the persmission
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 200
            )
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if(requestCode == 200) {
            val locationResult = grantResults[0]
            if(locationResult == PackageManager.PERMISSION_GRANTED) {
                //user clicked allow
                getCurrentLocation()

            } else {
                //user clicked deny
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if(!shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
                        Toast.makeText(
                            this,
                            "Please go into your settings and enable location for Android Tweets",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    private fun getCurrentLocation() {
        /*locationProvider.lastLocation.addOnSuccessListener { location: Location? ->
            if(location !=  null) {
                val latLng = LatLng(location.latitude, location.longitude)
                doGeocoding(latLng)
            }
        }*/
        locationProvider.requestLocationUpdates(
            LocationRequest.create(),
            locationCallback,
            null
        )
    }

    private val locationCallback = object: LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            super.onLocationResult(locationResult)

            locationProvider.removeLocationUpdates(this)
            val location = locationResult.locations[0]
            val latLng = LatLng(location.latitude, location.longitude)
            doGeocoding(latLng)
        }
    }

    private fun doGeocoding(latLng: LatLng) {
        doAsync {
            val geocoder = Geocoder(this@MapsActivity)
            val results: List<Address> =
                geocoder.getFromLocation(latLng.latitude, latLng.longitude, 5)

            runOnUiThread {
                if (results.isNotEmpty()) {
                    val firstAddress = results[0]
                    val title = firstAddress.getAddressLine(0)
                    val state = firstAddress.adminArea ?: "unknown"

                    mMap.addMarker(
                        MarkerOptions().position(latLng).title("Your Marker")
                    )
                    val zoomLevel = 12.0f
                    // You can also use moveCamera if you don't want the animation
                    mMap.animateCamera(
                        CameraUpdateFactory.newLatLngZoom(latLng, zoomLevel)
                    )
                    updateConfirmButton(firstAddress)

                    confirm.setOnClickListener {
                        val intent = Intent(this@MapsActivity, TweetsActivity::class.java)
                        intent.putExtra("state", state)
                        intent.putExtra("latitude", latLng.latitude)
                        intent.putExtra("longitude", latLng.longitude)
                        intent.putExtra("address", title)
                        startActivity(intent)
                    }
                } else {
                    Log.e("MapsActivity", "No results found")
                }
            }
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        // val latLng = LatLng(38.898365, -77.046753)
        // val title = "GWU"
        mMap.setOnMapLongClickListener { latLng ->
            mMap.clear()
            doGeocoding(latLng)
        }
    }

    private fun updateConfirmButton(address: Address) {
        // Update the button color -- need to load the color from resources first
        val greenColor = ContextCompat.getColor(
            this, R.color.buttonGreen // Defined in color.xml
        )
        val checkIcon = ContextCompat.getDrawable(
            this, R.drawable.ic_check_white
        )
        confirm.setBackgroundColor(greenColor)

        // Update the left-aligned icon
        confirm.setCompoundDrawablesWithIntrinsicBounds(checkIcon, null, null, null)

        //Update button text
        confirm.text = address.getAddressLine(0)
        confirm.isEnabled = true
    }
}
