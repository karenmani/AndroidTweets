package edu.gwu.androidtweetsfall2019

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TweetsAdapter(val tweets: List<Tweet>) : RecyclerView.Adapter<TweetsAdapter.TweetsViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TweetsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.row_tweet, parent, false)
        return TweetsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return tweets.size
    }

    override fun onBindViewHolder(holder: TweetsViewHolder, position: Int) {
        val currentTweet = tweets[position]
        holder.name.text = currentTweet.name
        holder.handle.text = currentTweet.handle
        holder.content.text = currentTweet.content
    }

    // Holds references to the Views in an already-inflated row
    class TweetsViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val icon: ImageView = view.findViewById(R.id.icon)
        val name: TextView = view.findViewById(R.id.username)
        val handle: TextView = view.findViewById(R.id.handle)
        val content: TextView = view.findViewById(R.id.tweet_content)
    }

}