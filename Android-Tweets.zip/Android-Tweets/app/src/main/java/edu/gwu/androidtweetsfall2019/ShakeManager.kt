package edu.gwu.androidtweetsfall2019

import android.content.Context
import android.hardware.SensorManager

class ShakeManager(context: Context) {

    private var callback: (() -> Unit)? = null
    private val sensorManager: SensorManager = context
        .getSystemService(Context.SENSOR_SERVICE) as SensorManager

    fun detectShakes(callback: () -> Unit) {
        this.callback = callback
    }

    fun stopDetectingShakes() {
        this.callback = null
    }
}