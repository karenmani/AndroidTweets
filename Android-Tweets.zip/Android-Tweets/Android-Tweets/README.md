# Android Tweets
An Android app where the user can select their location on a map and then see Android-related Tweets associated with that location.
